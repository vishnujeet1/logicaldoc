    __                _            __   ____  __      _           __
   / /   ____  ____ _(_)________ _/ /  / __ \/ /_    (_)__  _____/ /______
  / /   / __ \/ __ `/ / ___/ __ `/ /  / / / / __ \  / / _ \/ ___/ __/ ___/
 / /___/ /_/ / /_/ / / /__/ /_/ / /  / /_/ / /_/ / / /  __/ /__/ /_(__  )
/_____/\____/\__, /_/\___/\__,_/_/   \____/_.___/_/ /\___/\___/\__/____/
            /____/                             /___/

                      http://www.logicaldoc.com                    

                    LogicalDOC Community Edition


You need JDK 7 (AKA Java JDK 1.7), Maven 3.0.x

Launch the creation of the Eclipse project by doing:
mvn eclipse:eclipse

The previous command will also download the required jar dependencies

Open Eclipse 3.6 and you will be able to run the JUnit tests of Web-services on your installation of LogicalDOC 7.1.0
